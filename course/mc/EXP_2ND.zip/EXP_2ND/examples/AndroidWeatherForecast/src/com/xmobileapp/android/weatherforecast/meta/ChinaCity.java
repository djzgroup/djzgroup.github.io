package com.xmobileapp.android.weatherforecast.meta;

public class ChinaCity {

	
}
