package com.xmobileapp.android.weatherforecast.meta;

public class Constant {

	public static final String SOAP_ACTION = "http://www.webserviceX.NET/GetCitiesByCountry";
	public static final String METHOD_NAME = "GetCitiesByCountry";
    public static final String SOAP_ACTION2 = "http://www.webserviceX.NET/GetWeather";
    public static final String METHOD_NAME2 = "GetWeather";
    public static final String NAMESPACE = "http://www.webserviceX.NET";
    public static final String URL = "http://www.webservicex.net/globalweather.asmx";
}
